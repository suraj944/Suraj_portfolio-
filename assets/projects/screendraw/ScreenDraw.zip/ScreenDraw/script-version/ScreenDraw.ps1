﻿# ScreenDraw 1.1 (script version) - draw anywhere on your screen and take screenshots.
# Start it by double-clicking "Start ScreenDraw.bat" (in the same folder).
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms, System.Drawing

$code = @'
// ScreenDraw 1.1 - draw anywhere on your screen and take screenshots.
// Windows 10/11, .NET Framework 4.x (built into Windows). C# 5 compatible.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace ScreenDraw
{
    public enum Tool { Pen, Highlighter, Line, Arrow, Rect, Ellipse, Text, Eraser }

    internal static class Native
    {
        public const int GWL_EXSTYLE = -20;
        public const int WS_EX_LAYERED = 0x80000;
        public const int WS_EX_TRANSPARENT = 0x20;
        public const int WS_EX_TOOLWINDOW = 0x80;
        public const int WM_HOTKEY = 0x0312;
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HTCAPTION = 2;
        public const int ULW_ALPHA = 2;
        public const byte AC_SRC_OVER = 0;
        public const byte AC_SRC_ALPHA = 1;
        public const uint MOD_ALT = 1, MOD_CONTROL = 2, MOD_SHIFT = 4, MOD_NOREPEAT = 0x4000;

        [StructLayout(LayoutKind.Sequential)]
        public struct POINT { public int X; public int Y; public POINT(int x, int y) { X = x; Y = y; } }

        [StructLayout(LayoutKind.Sequential)]
        public struct SIZE { public int cx; public int cy; public SIZE(int x, int y) { cx = x; cy = y; } }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct BLENDFUNCTION { public byte BlendOp; public byte BlendFlags; public byte SourceConstantAlpha; public byte AlphaFormat; }

        [StructLayout(LayoutKind.Sequential)]
        public struct BITMAPINFOHEADER
        {
            public int biSize; public int biWidth; public int biHeight; public short biPlanes; public short biBitCount;
            public int biCompression; public int biSizeImage; public int biXPelsPerMeter; public int biYPelsPerMeter;
            public int biClrUsed; public int biClrImportant;
        }

        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool UpdateLayeredWindow(IntPtr hwnd, IntPtr hdcDst, ref POINT pptDst, ref SIZE psize,
            IntPtr hdcSrc, ref POINT pprSrc, int crKey, ref BLENDFUNCTION pblend, int dwFlags);
        [DllImport("user32.dll")] public static extern IntPtr GetDC(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);
        [DllImport("gdi32.dll")] public static extern IntPtr CreateCompatibleDC(IntPtr hDC);
        [DllImport("gdi32.dll")] public static extern bool DeleteDC(IntPtr hdc);
        [DllImport("gdi32.dll")] public static extern IntPtr SelectObject(IntPtr hDC, IntPtr hObject);
        [DllImport("gdi32.dll")] public static extern bool DeleteObject(IntPtr hObject);
        [DllImport("gdi32.dll")]
        public static extern IntPtr CreateDIBSection(IntPtr hdc, ref BITMAPINFOHEADER pbmi, uint iUsage,
            out IntPtr ppvBits, IntPtr hSection, uint dwOffset);
        [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr hWnd, int nIndex);
        [DllImport("user32.dll")] public static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);
        [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);
        [DllImport("user32.dll")] public static extern bool UnregisterHotKey(IntPtr hWnd, int id);
        [DllImport("user32.dll")] public static extern bool ReleaseCapture();
        [DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wp, IntPtr lp);
        [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
        [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr value);
        [DllImport("user32.dll")] public static extern bool DestroyIcon(IntPtr hIcon);
    }

    // ------------------------------------------------------------------ shapes
    public class Shape
    {
        public Tool Kind;
        public Color Color;
        public float Width;
        public List<Point> Points = new List<Point>();
        public Point A, B;
        public string Text;
        public float FontPx;

        static readonly Bitmap measureBmp = new Bitmap(1, 1);

        public static Rectangle Norm(Point a, Point b)
        {
            return Rectangle.FromLTRB(Math.Min(a.X, b.X), Math.Min(a.Y, b.Y), Math.Max(a.X, b.X), Math.Max(a.Y, b.Y));
        }

        public Font MakeFont() { return new Font("Segoe UI", FontPx, FontStyle.Bold, GraphicsUnit.Pixel); }

        Color StrokeColor { get { return Kind == Tool.Highlighter ? Color.FromArgb(110, Color) : Color; } }

        Pen MakePen()
        {
            Pen p = new Pen(StrokeColor, Width);
            p.StartCap = LineCap.Round; p.EndCap = LineCap.Round; p.LineJoin = LineJoin.Round;
            return p;
        }

        public Rectangle TextBounds()
        {
            using (Graphics g = Graphics.FromImage(measureBmp))
            using (Font f = MakeFont())
            {
                SizeF s = g.MeasureString(Text ?? "", f);
                return new Rectangle(A.X, A.Y, (int)Math.Ceiling(s.Width), (int)Math.Ceiling(s.Height));
            }
        }

        public Rectangle Bounds()
        {
            Rectangle r;
            if (Kind == Tool.Text) { r = TextBounds(); r.Inflate(3, 3); return r; }
            if (Kind == Tool.Pen || Kind == Tool.Highlighter)
            {
                int x0 = int.MaxValue, y0 = int.MaxValue, x1 = int.MinValue, y1 = int.MinValue;
                foreach (Point p in Points)
                {
                    if (p.X < x0) x0 = p.X; if (p.Y < y0) y0 = p.Y;
                    if (p.X > x1) x1 = p.X; if (p.Y > y1) y1 = p.Y;
                }
                if (Points.Count == 0) return Rectangle.Empty;
                r = Rectangle.FromLTRB(x0, y0, x1, y1);
            }
            else r = Norm(A, B);
            int pad = (int)Math.Ceiling(Width / 2f) + 3;
            if (Kind == Tool.Arrow) pad += (int)Math.Max(12f, Width * 4f);
            r.Inflate(pad, pad);
            return r;
        }

        public void Draw(Graphics g)
        {
            switch (Kind)
            {
                case Tool.Pen:
                case Tool.Highlighter:
                    if (Points.Count == 0) break;
                    Rectangle bb = Bounds();
                    bool isDot = Points.Count == 1 || (bb.Width <= Width + 7 && bb.Height <= Width + 7 && AllSame());
                    if (isDot)
                    {
                        using (SolidBrush b = new SolidBrush(StrokeColor))
                            g.FillEllipse(b, Points[0].X - Width / 2f, Points[0].Y - Width / 2f, Width, Width);
                    }
                    else using (Pen p = MakePen()) g.DrawLines(p, Points.ToArray());
                    break;
                case Tool.Line:
                    using (Pen p = MakePen()) g.DrawLine(p, A, B);
                    break;
                case Tool.Arrow:
                    DrawArrow(g);
                    break;
                case Tool.Rect:
                    using (Pen p = MakePen()) g.DrawRectangle(p, Norm(A, B));
                    break;
                case Tool.Ellipse:
                    using (Pen p = MakePen()) g.DrawEllipse(p, Norm(A, B));
                    break;
                case Tool.Text:
                    using (Font f = MakeFont())
                    using (SolidBrush b = new SolidBrush(Color))
                        g.DrawString(Text, f, b, A);
                    break;
            }
        }

        bool AllSame()
        {
            for (int i = 1; i < Points.Count; i++) if (Points[i] != Points[0]) return false;
            return true;
        }

        void DrawArrow(Graphics g)
        {
            float dx = B.X - A.X, dy = B.Y - A.Y;
            float len = (float)Math.Sqrt(dx * dx + dy * dy);
            using (Pen p = MakePen())
            {
                if (len < 2) { g.DrawLine(p, A, B); return; }
                float head = Math.Max(12f, Width * 4f);
                if (head > len) head = len;
                float ux = dx / len, uy = dy / len;
                PointF tip = new PointF(B.X, B.Y);
                PointF basePt = new PointF(B.X - ux * head, B.Y - uy * head);
                float hw = head * 0.55f;
                PointF left = new PointF(basePt.X - uy * hw, basePt.Y + ux * hw);
                PointF right = new PointF(basePt.X + uy * hw, basePt.Y - ux * hw);
                PointF lineEnd = new PointF(B.X - ux * head * 0.6f, B.Y - uy * head * 0.6f);
                g.DrawLine(p, new PointF(A.X, A.Y), lineEnd);
                using (SolidBrush b = new SolidBrush(p.Color)) g.FillPolygon(b, new PointF[] { tip, left, right });
            }
        }

        public bool HitTest(Point pt, float radius)
        {
            Rectangle bb = Bounds();
            bb.Inflate((int)radius + 2, (int)radius + 2);
            if (!bb.Contains(pt)) return false;
            if (Kind == Tool.Text) return true;
            double lim = Width / 2.0 + radius;
            List<PointF> poly = new List<PointF>();
            bool closed = false;
            Rectangle r;
            switch (Kind)
            {
                case Tool.Pen:
                case Tool.Highlighter:
                    foreach (Point q in Points) poly.Add(q);
                    break;
                case Tool.Line:
                case Tool.Arrow:
                    poly.Add(A); poly.Add(B);
                    break;
                case Tool.Rect:
                    r = Norm(A, B);
                    poly.Add(new PointF(r.Left, r.Top)); poly.Add(new PointF(r.Right, r.Top));
                    poly.Add(new PointF(r.Right, r.Bottom)); poly.Add(new PointF(r.Left, r.Bottom));
                    closed = true;
                    break;
                case Tool.Ellipse:
                    r = Norm(A, B);
                    double cx = r.X + r.Width / 2.0, cy = r.Y + r.Height / 2.0;
                    for (int i = 0; i < 72; i++)
                    {
                        double t = i * Math.PI * 2 / 72;
                        poly.Add(new PointF((float)(cx + Math.Cos(t) * r.Width / 2.0), (float)(cy + Math.Sin(t) * r.Height / 2.0)));
                    }
                    closed = true;
                    break;
            }
            if (poly.Count == 0) return false;
            if (poly.Count == 1) return Dist(pt, poly[0], poly[0]) <= lim;
            for (int i = 1; i < poly.Count; i++)
                if (Dist(pt, poly[i - 1], poly[i]) <= lim) return true;
            if (closed && Dist(pt, poly[poly.Count - 1], poly[0]) <= lim) return true;
            return false;
        }

        static double Dist(Point p, PointF a, PointF b)
        {
            double dx = b.X - a.X, dy = b.Y - a.Y;
            double len2 = dx * dx + dy * dy;
            double t = len2 == 0 ? 0 : ((p.X - a.X) * dx + (p.Y - a.Y) * dy) / len2;
            if (t < 0) t = 0; else if (t > 1) t = 1;
            double ex = a.X + t * dx - p.X, ey = a.Y + t * dy - p.Y;
            return Math.Sqrt(ex * ex + ey * ey);
        }
    }

    // ------------------------------------------------------------------ overlay (the drawing surface)
    public class Overlay : Form
    {
        public static readonly Color[] Palette = new Color[] {
            Color.FromArgb(235, 40, 40),   // red
            Color.FromArgb(255, 140, 0),   // orange
            Color.FromArgb(255, 214, 0),   // yellow
            Color.FromArgb(0, 200, 83),    // green
            Color.FromArgb(41, 121, 255),  // blue
            Color.FromArgb(170, 0, 255),   // purple
            Color.FromArgb(20, 20, 20),    // black
            Color.FromArgb(255, 255, 255)  // white
        };
        public static readonly float[] Sizes = new float[] { 2, 3, 4, 6, 8, 12, 16, 24 };

        public Tool CurrentTool = Tool.Pen;
        public Color CurrentColor = Palette[0];
        public float PenWidth = 4;
        int sizeIndex = 2;

        Rectangle vs;
        IntPtr memDC = IntPtr.Zero, hDib = IntPtr.Zero, oldObj = IntPtr.Zero, bits = IntPtr.Zero;
        Bitmap canvas, baseBmp;

        List<Shape> shapes = new List<Shape>();
        // undo / redo history (List used as a stack: last item = top)
        List<List<Shape>> undo = new List<List<Shape>>();
        List<List<Shape>> redo = new List<List<Shape>>();

        static void PushTo(List<List<Shape>> st, List<Shape> item) { st.Add(item); }
        static List<Shape> PopFrom(List<List<Shape>> st)
        {
            List<Shape> top = st[st.Count - 1];
            st.RemoveAt(st.Count - 1);
            return top;
        }
        List<Shape> pendingSnapshot;
        bool erasedAny;

        Shape current;
        bool drawing;
        Point mouse;
        bool mouseInside;
        Rectangle lastLive = Rectangle.Empty;

        bool drawMode = true;
        bool hiddenForCapture;

        Toolbar toolbar;
        NotifyIcon tray;
        Icon appIcon;
        string saveDir;
        string lastSaved;
        bool balloonIsShot;

        const int HK_DRAW = 1, HK_SHOT = 2, HK_SNIP = 3, HK_CLEAR = 4, HK_TOOLBAR = 5;

        public bool DrawMode { get { return drawMode; } }

        public Overlay()
        {
            vs = SystemInformation.VirtualScreen;
            Text = "ScreenDraw";
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.Manual;
            AutoScaleMode = AutoScaleMode.None;
            Bounds = vs;
            TopMost = true;
            KeyPreview = true;
            Cursor = Cursors.Cross;
            saveDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), "ScreenDraw");
            Log.Write("Screens: " + vs + ", monitors: " + Screen.AllScreens.Length);
            appIcon = MakeIcon();
            Icon = appIcon;
            CreateSurfaces();
            Log.Write("Surfaces created (DIB " + (hDib != IntPtr.Zero) + ")");
            Microsoft.Win32.SystemEvents.DisplaySettingsChanged += OnDisplayChanged;
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= Native.WS_EX_LAYERED | Native.WS_EX_TOOLWINDOW;
                if (!drawMode) cp.ExStyle |= Native.WS_EX_TRANSPARENT;
                return cp;
            }
        }

        // ---------- surfaces
        void CreateSurfaces()
        {
            Native.BITMAPINFOHEADER bi = new Native.BITMAPINFOHEADER();
            bi.biSize = Marshal.SizeOf(typeof(Native.BITMAPINFOHEADER));
            bi.biWidth = vs.Width;
            bi.biHeight = -vs.Height; // top-down
            bi.biPlanes = 1;
            bi.biBitCount = 32;
            bi.biCompression = 0;
            IntPtr screenDC = Native.GetDC(IntPtr.Zero);
            memDC = Native.CreateCompatibleDC(screenDC);
            Native.ReleaseDC(IntPtr.Zero, screenDC);
            hDib = Native.CreateDIBSection(memDC, ref bi, 0, out bits, IntPtr.Zero, 0);
            oldObj = Native.SelectObject(memDC, hDib);
            canvas = new Bitmap(vs.Width, vs.Height, vs.Width * 4, PixelFormat.Format32bppPArgb, bits);
            baseBmp = new Bitmap(vs.Width, vs.Height, PixelFormat.Format32bppPArgb);
            lastLive = Rectangle.Empty;
            RebuildBase();
        }

        void ReleaseSurfaces()
        {
            if (canvas != null) { canvas.Dispose(); canvas = null; }
            if (baseBmp != null) { baseBmp.Dispose(); baseBmp = null; }
            if (memDC != IntPtr.Zero)
            {
                Native.SelectObject(memDC, oldObj);
                Native.DeleteObject(hDib);
                Native.DeleteDC(memDC);
                memDC = IntPtr.Zero; hDib = IntPtr.Zero;
            }
        }

        void OnDisplayChanged(object sender, EventArgs e)
        {
            if (!IsHandleCreated) return;
            BeginInvoke((MethodInvoker)delegate
            {
                ReleaseSurfaces();
                vs = SystemInformation.VirtualScreen;
                CreateSurfaces();
                Render();
                if (toolbar != null) toolbar.EnsureOnScreen();
            });
        }

        static void Setup(Graphics g)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
        }

        void RebuildBase()
        {
            if (baseBmp == null) return;
            using (Graphics g = Graphics.FromImage(baseBmp))
            {
                g.CompositingMode = CompositingMode.SourceCopy;
                // alpha 1 = invisible, but still catches the mouse while drawing is ON
                using (SolidBrush b = new SolidBrush(Color.FromArgb(drawMode ? 1 : 0, 0, 0, 0)))
                    g.FillRectangle(b, 0, 0, baseBmp.Width, baseBmp.Height);
                g.CompositingMode = CompositingMode.SourceOver;
                Setup(g);
                foreach (Shape s in shapes) s.Draw(g);
            }
        }

        static Rectangle U(Rectangle a, Rectangle b)
        {
            if (a.IsEmpty) return b;
            if (b.IsEmpty) return a;
            return Rectangle.Union(a, b);
        }

        float EraserRadius { get { return Math.Max(8f, PenWidth * 2f); } }

        Rectangle LiveBounds()
        {
            Rectangle r = Rectangle.Empty;
            if (current != null) r = current.Bounds();
            if (drawMode && CurrentTool == Tool.Eraser && mouseInside && !hiddenForCapture)
            {
                int rad = (int)Math.Ceiling(EraserRadius) + 4;
                r = U(r, new Rectangle(mouse.X - rad, mouse.Y - rad, rad * 2, rad * 2));
            }
            return r;
        }

        void Render() { RenderInternal(true); }
        void RenderLive() { RenderInternal(false); }

        void RenderInternal(bool full)
        {
            if (canvas == null || !IsHandleCreated) return;
            Rectangle all = new Rectangle(0, 0, vs.Width, vs.Height);
            Rectangle now = LiveBounds();
            Rectangle dirty = full ? all : U(lastLive, now);
            lastLive = now;
            if (dirty.IsEmpty) return;
            dirty.Inflate(4, 4);
            dirty.Intersect(all);
            if (dirty.IsEmpty) return;

            using (Graphics g = Graphics.FromImage(canvas))
            {
                g.SetClip(dirty);
                g.CompositingMode = CompositingMode.SourceCopy;
                g.InterpolationMode = InterpolationMode.NearestNeighbor;
                g.PixelOffsetMode = PixelOffsetMode.Half;
                if (hiddenForCapture)
                {
                    using (SolidBrush clear = new SolidBrush(Color.FromArgb(0, 0, 0, 0))) g.FillRectangle(clear, dirty);
                }
                else
                {
                    g.DrawImage(baseBmp, dirty, dirty, GraphicsUnit.Pixel);
                    g.CompositingMode = CompositingMode.SourceOver;
                    g.PixelOffsetMode = PixelOffsetMode.Default;
                    Setup(g);
                    if (current != null) current.Draw(g);
                    if (drawMode && CurrentTool == Tool.Eraser && mouseInside)
                    {
                        float r = EraserRadius;
                        using (Pen dark = new Pen(Color.FromArgb(200, 0, 0, 0), 3f))
                            g.DrawEllipse(dark, mouse.X - r, mouse.Y - r, r * 2, r * 2);
                        using (Pen light = new Pen(Color.White, 1.5f))
                            g.DrawEllipse(light, mouse.X - r, mouse.Y - r, r * 2, r * 2);
                    }
                }
            }
            Push();
        }

        void Push()
        {
            Native.POINT dst = new Native.POINT(vs.X, vs.Y);
            Native.SIZE sz = new Native.SIZE(vs.Width, vs.Height);
            Native.POINT src = new Native.POINT(0, 0);
            Native.BLENDFUNCTION bf = new Native.BLENDFUNCTION();
            bf.BlendOp = Native.AC_SRC_OVER;
            bf.BlendFlags = 0;
            bf.SourceConstantAlpha = 255;
            bf.AlphaFormat = Native.AC_SRC_ALPHA;
            bool ok = Native.UpdateLayeredWindow(Handle, IntPtr.Zero, ref dst, ref sz, memDC, ref src, 0, ref bf, Native.ULW_ALPHA);
            if (!ok && !ulwFailLogged)
            {
                ulwFailLogged = true;
                Log.Write("UpdateLayeredWindow FAILED, error " + Marshal.GetLastWin32Error() + ", size " + vs);
            }
            else if (ok && !ulwOkLogged) { ulwOkLogged = true; Log.Write("Drawing surface OK (" + vs.Width + "x" + vs.Height + ")"); }
        }
        bool ulwFailLogged, ulwOkLogged;

        protected override void OnPaintBackground(PaintEventArgs e) { }
        protected override void OnPaint(PaintEventArgs e) { }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            Render();
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            Log.Write("Overlay shown. Window handle " + Handle);
            try
            {
                toolbar = new Toolbar(this);
                toolbar.Show(this);
                toolbar.TopMost = true;
                Log.Write("Toolbar shown at " + toolbar.Bounds);
            }
            catch (Exception ex) { Program.Fail("Could not create the toolbar.", ex); }

            try { SetupTray(); } catch (Exception ex) { Log.Write("Tray/hotkey setup failed: " + ex); }

            try
            {
                StartupNotice n = new StartupNotice(toolbar != null ? toolbar.Bottom : 0);
                n.Show(this);
            }
            catch (Exception ex) { Log.Write("Startup notice failed: " + ex); }

            Activate();
        }

        void SetupTray()
        {
            tray = new NotifyIcon();
            tray.Icon = appIcon;
            tray.Text = "ScreenDraw";
            BuildMenu();
            tray.ContextMenuStrip = menu;
            tray.DoubleClick += delegate { ToggleToolbar(); };
            tray.BalloonTipClicked += delegate { if (balloonIsShot) OpenFolder(); };
            tray.Visible = true;

            bool ok = true;
            uint mods = Native.MOD_CONTROL | Native.MOD_ALT | Native.MOD_NOREPEAT;
            ok &= Native.RegisterHotKey(Handle, HK_DRAW, mods, (uint)Keys.D);
            ok &= Native.RegisterHotKey(Handle, HK_SHOT, mods, (uint)Keys.S);
            ok &= Native.RegisterHotKey(Handle, HK_SNIP, mods, (uint)Keys.R);
            ok &= Native.RegisterHotKey(Handle, HK_CLEAR, mods, (uint)Keys.C);
            ok &= Native.RegisterHotKey(Handle, HK_TOOLBAR, mods, (uint)Keys.H);

            balloonIsShot = false;
            tray.ShowBalloonTip(4000, "ScreenDraw is running",
                "Draw anywhere. Esc or Ctrl+Alt+D = drawing on/off.\nCtrl+Alt+S = screenshot, Ctrl+Alt+R = snip an area." +
                (ok ? "" : "\n(Some shortcuts are used by another app.)"), ToolTipIcon.Info);
            Log.Write("Tray icon and menu ready. Hotkeys registered: " + ok);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == Native.WM_HOTKEY)
            {
                switch (m.WParam.ToInt32())
                {
                    case HK_DRAW: ToggleDraw(); break;
                    case HK_SHOT: Screenshot(false); break;
                    case HK_SNIP: Screenshot(true); break;
                    case HK_CLEAR: ClearAll(); break;
                    case HK_TOOLBAR: ToggleToolbar(); break;
                }
                return;
            }
            base.WndProc(ref m);
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Microsoft.Win32.SystemEvents.DisplaySettingsChanged -= OnDisplayChanged;
            for (int i = 1; i <= 5; i++) Native.UnregisterHotKey(Handle, i);
            if (tray != null) { tray.Visible = false; tray.Dispose(); }
            ReleaseSurfaces();
            base.OnFormClosed(e);
        }

        // ---------- mouse
        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (!drawMode || hiddenForCapture) return;
            if (e.Button == MouseButtons.Right && !drawing) { ShowMenu(Cursor.Position); return; }
            if (e.Button != MouseButtons.Left) return;
            Point p = e.Location;
            if (CurrentTool == Tool.Text) { BeginText(p); return; }
            if (CurrentTool == Tool.Eraser)
            {
                pendingSnapshot = new List<Shape>(shapes);
                erasedAny = false;
                drawing = true;
                EraseAt(p);
                return;
            }
            current = new Shape();
            current.Kind = CurrentTool;
            current.Color = CurrentColor;
            current.Width = CurrentTool == Tool.Highlighter ? Math.Max(14f, PenWidth * 3f) : PenWidth;
            current.A = p; current.B = p;
            current.Points.Add(p);
            drawing = true;
            Capture = true;
            RenderLive();
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            mouse = e.Location;
            mouseInside = true;
            if (!drawMode) return;
            if (drawing)
            {
                if (CurrentTool == Tool.Eraser) EraseAt(e.Location);
                else if (current != null)
                {
                    if (current.Kind == Tool.Pen || current.Kind == Tool.Highlighter)
                    {
                        Point last = current.Points[current.Points.Count - 1];
                        if (last != e.Location) current.Points.Add(e.Location);
                    }
                    else
                    {
                        Point b = e.Location;
                        if ((ModifierKeys & Keys.Shift) != 0) b = Constrain(current.A, b, current.Kind);
                        current.B = b;
                    }
                }
                RenderLive();
            }
            else if (CurrentTool == Tool.Eraser) RenderLive();
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            if (!drawing) return;
            drawing = false;
            Capture = false;
            if (current != null)
            {
                PushUndo();
                shapes.Add(current);
                current = null;
                RebuildBase();
                Render();
            }
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            mouseInside = false;
            if (CurrentTool == Tool.Eraser) RenderLive();
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            base.OnMouseWheel(e);
            if (drawMode) ChangeSize(e.Delta > 0 ? 1 : -1);
        }

        static Point Constrain(Point a, Point b, Tool k)
        {
            int dx = b.X - a.X, dy = b.Y - a.Y;
            if (k == Tool.Rect || k == Tool.Ellipse)
            {
                int m = Math.Max(Math.Abs(dx), Math.Abs(dy));
                return new Point(a.X + Math.Sign(dx == 0 ? 1 : dx) * m, a.Y + Math.Sign(dy == 0 ? 1 : dy) * m);
            }
            double ang = Math.Atan2(dy, dx);
            double snap = Math.Round(ang / (Math.PI / 4)) * (Math.PI / 4);
            double len = Math.Sqrt(dx * dx + dy * dy);
            return new Point(a.X + (int)Math.Round(Math.Cos(snap) * len), a.Y + (int)Math.Round(Math.Sin(snap) * len));
        }

        void EraseAt(Point p)
        {
            bool changed = false;
            for (int i = shapes.Count - 1; i >= 0; i--)
            {
                if (shapes[i].HitTest(p, EraserRadius))
                {
                    if (!erasedAny) { PushTo(undo, pendingSnapshot); redo.Clear(); erasedAny = true; }
                    shapes.RemoveAt(i);
                    changed = true;
                }
            }
            if (changed) { RebuildBase(); Render(); }
        }

        void BeginText(Point p)
        {
            float px = 12f + PenWidth * 3f;
            Font f = new Font("Segoe UI", px, FontStyle.Bold, GraphicsUnit.Pixel);
            string text = null;
            using (TextInput ti = new TextInput(f, CurrentColor))
            {
                ti.Location = new Point(p.X + vs.X - 3, p.Y + vs.Y - 3);
                if (ti.ShowDialog(this) == DialogResult.OK) text = ti.Value;
            }
            f.Dispose();
            if (string.IsNullOrEmpty(text) || text.Trim().Length == 0) return;
            PushUndo();
            Shape s = new Shape();
            s.Kind = Tool.Text; s.Color = CurrentColor; s.Width = PenWidth; s.FontPx = px; s.Text = text; s.A = p; s.B = p;
            shapes.Add(s);
            RebuildBase();
            Render();
            Activate();
        }

        // ---------- keyboard
        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            HandleKey(e);
        }

        public void HandleKey(KeyEventArgs e)
        {
            if (e.Control && !e.Alt)
            {
                if (e.KeyCode == Keys.Z) { Undo(); e.Handled = true; }
                else if (e.KeyCode == Keys.Y) { Redo(); e.Handled = true; }
                return;
            }
            if (e.Alt || e.Control) return;
            switch (e.KeyCode)
            {
                case Keys.Escape:
                    if (drawing && current != null) { current = null; drawing = false; Capture = false; RenderLive(); }
                    else SetDrawMode(false);
                    break;
                case Keys.P: SetTool(Tool.Pen); break;
                case Keys.H: SetTool(Tool.Highlighter); break;
                case Keys.L: SetTool(Tool.Line); break;
                case Keys.A: SetTool(Tool.Arrow); break;
                case Keys.R: SetTool(Tool.Rect); break;
                case Keys.E: SetTool(Tool.Ellipse); break;
                case Keys.T: SetTool(Tool.Text); break;
                case Keys.X: SetTool(Tool.Eraser); break;
                case Keys.Delete: ClearAll(); break;
                case Keys.M: case Keys.Apps: ShowMenu(Cursor.Position); break;
                case Keys.Oemplus: case Keys.Add: ChangeSize(1); break;
                case Keys.OemMinus: case Keys.Subtract: ChangeSize(-1); break;
                default:
                    int idx = -1;
                    if (e.KeyCode >= Keys.D1 && e.KeyCode <= Keys.D8) idx = e.KeyCode - Keys.D1;
                    else if (e.KeyCode >= Keys.NumPad1 && e.KeyCode <= Keys.NumPad8) idx = e.KeyCode - Keys.NumPad1;
                    if (idx >= 0) SetColor(idx); else return;
                    break;
            }
            e.Handled = true;
        }

        // ---------- commands
        void PushUndo()
        {
            PushTo(undo, new List<Shape>(shapes));
            redo.Clear();
        }

        public void Undo()
        {
            if (drawing || undo.Count == 0) return;
            PushTo(redo, shapes);
            shapes = PopFrom(undo);
            RebuildBase(); Render();
        }

        public void Redo()
        {
            if (drawing || redo.Count == 0) return;
            PushTo(undo, shapes);
            shapes = PopFrom(redo);
            RebuildBase(); Render();
        }

        public void ClearAll()
        {
            if (drawing || shapes.Count == 0) return;
            PushUndo();
            shapes = new List<Shape>();
            RebuildBase(); Render();
        }

        public void SetTool(Tool t)
        {
            CurrentTool = t;
            if (!drawMode) SetDrawMode(true);
            RenderLive();
            if (toolbar != null) toolbar.UpdateState();
        }

        public void SetColor(int idx)
        {
            if (idx < 0 || idx >= Palette.Length) return;
            CurrentColor = Palette[idx];
            if (CurrentTool == Tool.Eraser) CurrentTool = Tool.Pen;
            if (!drawMode) SetDrawMode(true);
            if (toolbar != null) toolbar.UpdateState();
        }

        public void ChangeSize(int d)
        {
            sizeIndex = Math.Max(0, Math.Min(Sizes.Length - 1, sizeIndex + d));
            PenWidth = Sizes[sizeIndex];
            RenderLive();
            if (toolbar != null) toolbar.UpdateState();
        }

        public void ToggleDraw() { SetDrawMode(!drawMode); }

        public void SetDrawMode(bool on)
        {
            if (on == drawMode) { if (on) BringToFrontForDrawing(); return; }
            drawMode = on;
            drawing = false; current = null; Capture = false;
            int ex = Native.GetWindowLong(Handle, Native.GWL_EXSTYLE);
            if (on) ex &= ~Native.WS_EX_TRANSPARENT; else ex |= Native.WS_EX_TRANSPARENT;
            Native.SetWindowLong(Handle, Native.GWL_EXSTYLE, ex);
            lastLive = Rectangle.Empty;
            RebuildBase();
            Render();
            if (on) BringToFrontForDrawing();
            if (toolbar != null) toolbar.UpdateState();
        }

        void BringToFrontForDrawing()
        {
            TopMost = true;
            if (toolbar != null && toolbar.Visible) toolbar.TopMost = true;
            Activate();
            Native.SetForegroundWindow(Handle);
        }

        public void ToggleToolbar()
        {
            if (toolbar == null) return;
            if (toolbar.Visible) toolbar.Hide();
            else { toolbar.Show(); toolbar.EnsureOnScreen(); toolbar.TopMost = true; }
        }

        // ---------- screenshots
        Bitmap CaptureComposite()
        {
            bool tbVisible = toolbar != null && toolbar.Visible;
            if (tbVisible) toolbar.Hide();
            hiddenForCapture = true;
            Render();
            Application.DoEvents();
            Thread.Sleep(250);
            Application.DoEvents();

            Bitmap bmp = new Bitmap(vs.Width, vs.Height, PixelFormat.Format32bppArgb);
            try
            {
                using (Graphics g = Graphics.FromImage(bmp))
                {
                    g.CopyFromScreen(vs.Location, Point.Empty, vs.Size);
                    Setup(g);
                    foreach (Shape s in shapes) s.Draw(g);
                }
            }
            finally
            {
                hiddenForCapture = false;
                Render();
                if (tbVisible) toolbar.Show();
            }
            return bmp;
        }

        public void Screenshot(bool region) { Screenshot(region ? 1 : 0); }

        // mode: 0 = full screen, 1 = snip an area, 2 = full screen + choose where to save
        public void Screenshot(int mode)
        {
            if (drawing) return;
            try
            {
                using (Bitmap full = CaptureComposite())
                {
                    if (mode == 0) { SaveShot(full, null); return; }
                    if (mode == 2)
                    {
                        using (SaveFileDialog d = new SaveFileDialog())
                        {
                            d.Title = "Save screenshot as";
                            d.Filter = "PNG image (*.png)|*.png|JPEG image (*.jpg)|*.jpg|Bitmap (*.bmp)|*.bmp";
                            d.FileName = "Screenshot_" + DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss");
                            Directory.CreateDirectory(saveDir);
                            d.InitialDirectory = saveDir;
                            d.OverwritePrompt = true;
                            if (d.ShowDialog(toolbar != null && toolbar.Visible ? (IWin32Window)toolbar : this) != DialogResult.OK) return;
                            SaveShot(full, d.FileName);
                        }
                        return;
                    }
                    Rectangle r;
                    using (RegionSelector rs = new RegionSelector(full, vs))
                    {
                        if (rs.ShowDialog() != DialogResult.OK) return;
                        r = rs.Selection;
                    }
                    r.Intersect(new Rectangle(0, 0, full.Width, full.Height));
                    if (r.Width < 2 || r.Height < 2) return;
                    using (Bitmap crop = full.Clone(r, full.PixelFormat)) SaveShot(crop, null);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not take the screenshot:\n" + ex.Message, "ScreenDraw", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally
            {
                if (drawMode) BringToFrontForDrawing();
            }
        }

        void SaveShot(Bitmap bmp, string chosenPath)
        {
            string path = chosenPath;
            if (path == null)
            {
                Directory.CreateDirectory(saveDir);
                string name = "Screenshot_" + DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss");
                path = Path.Combine(saveDir, name + ".png");
                int n = 2;
                while (File.Exists(path)) { path = Path.Combine(saveDir, name + "_" + n + ".png"); n++; }
            }
            string ext = Path.GetExtension(path).ToLowerInvariant();
            if (ext == ".jpg" || ext == ".jpeg")
            {
                using (Bitmap rgb = new Bitmap(bmp.Width, bmp.Height, PixelFormat.Format24bppRgb))
                {
                    using (Graphics g = Graphics.FromImage(rgb)) g.DrawImageUnscaled(bmp, 0, 0);
                    rgb.Save(path, ImageFormat.Jpeg);
                }
            }
            else if (ext == ".bmp") bmp.Save(path, ImageFormat.Bmp);
            else bmp.Save(path, ImageFormat.Png);
            bool copied = true;
            try { Clipboard.SetImage(bmp); } catch { copied = false; }
            lastSaved = path;
            balloonIsShot = true;
            tray.ShowBalloonTip(3000, "Screenshot saved",
                Path.GetFileName(path) + (copied ? "\nAlso copied - paste it anywhere with Ctrl+V." : "") + "\nClick here to open the folder.",
                ToolTipIcon.Info);
        }

        // ---------- the menu (toolbar "Menu" button, right-click while drawing, tray icon)
        ContextMenuStrip menu;
        Dictionary<Tool, ToolStripMenuItem> toolItems = new Dictionary<Tool, ToolStripMenuItem>();
        List<ToolStripMenuItem> colorItems = new List<ToolStripMenuItem>();
        List<ToolStripMenuItem> sizeItems = new List<ToolStripMenuItem>();
        ToolStripMenuItem drawItem, toolbarItem, undoItem, redoItem, clearItem;

        static readonly string[] ColorNames = new string[] { "Red", "Orange", "Yellow", "Green", "Blue", "Purple", "Black", "White" };

        ToolStripMenuItem Item(string text, string keys, EventHandler click)
        {
            ToolStripMenuItem it = new ToolStripMenuItem(text);
            if (keys != null) it.ShortcutKeyDisplayString = keys;
            if (click != null) it.Click += click;
            return it;
        }

        // run after the menu has closed (so it never shows up in a screenshot)
        EventHandler Later(MethodInvoker action)
        {
            return delegate { BeginInvoke(action); };
        }

        void BuildMenu()
        {
            float dpi;
            using (Graphics g = Graphics.FromHwnd(IntPtr.Zero)) dpi = g.DpiX / 96f;
            int icon = (int)Math.Round(16 * dpi);

            menu = new ContextMenuStrip();
            menu.Renderer = new DarkRenderer();
            menu.Font = new Font("Segoe UI", 12f * dpi, FontStyle.Regular, GraphicsUnit.Pixel);
            menu.ImageScalingSize = new Size(icon, icon);
            menu.ShowCheckMargin = true;
            menu.ShowImageMargin = true;

            ToolStripMenuItem tools = Item("Tool", null, null);
            AddToolItem(tools, Tool.Pen, "Pen", "P");
            AddToolItem(tools, Tool.Highlighter, "Marker (highlighter)", "H");
            AddToolItem(tools, Tool.Line, "Line", "L");
            AddToolItem(tools, Tool.Arrow, "Arrow", "A");
            AddToolItem(tools, Tool.Rect, "Box", "R");
            AddToolItem(tools, Tool.Ellipse, "Circle", "E");
            AddToolItem(tools, Tool.Text, "Text", "T");
            AddToolItem(tools, Tool.Eraser, "Eraser", "X");
            menu.Items.Add(tools);

            ToolStripMenuItem colors = Item("Color", null, null);
            for (int i = 0; i < Palette.Length; i++)
            {
                int idx = i;
                ToolStripMenuItem c = Item(ColorNames[i], (i + 1).ToString(), delegate { SetColor(idx); });
                c.Image = Swatch(Palette[i], icon);
                colors.DropDownItems.Add(c);
                colorItems.Add(c);
            }
            menu.Items.Add(colors);

            ToolStripMenuItem sizes = Item("Pen size", "+ / -", null);
            for (int i = 0; i < Sizes.Length; i++)
            {
                int idx = i;
                ToolStripMenuItem z = Item(Sizes[i] + " px", null, delegate { SetSizeIndex(idx); });
                z.Image = SizeDot(Sizes[i], icon);
                sizes.DropDownItems.Add(z);
                sizeItems.Add(z);
            }
            menu.Items.Add(sizes);
            menu.Items.Add(new ToolStripSeparator());

            undoItem = Item("Undo", "Ctrl+Z", delegate { Undo(); });
            redoItem = Item("Redo", "Ctrl+Y", delegate { Redo(); });
            clearItem = Item("Clear all drawings", "Delete", delegate { ClearAll(); });
            menu.Items.Add(undoItem);
            menu.Items.Add(redoItem);
            menu.Items.Add(clearItem);
            menu.Items.Add(new ToolStripSeparator());

            menu.Items.Add(Item("Screenshot (full screen)", "Ctrl+Alt+S", Later(delegate { Screenshot(0); })));
            menu.Items.Add(Item("Snip an area", "Ctrl+Alt+R", Later(delegate { Screenshot(1); })));
            menu.Items.Add(Item("Save screenshot as...", null, Later(delegate { Screenshot(2); })));
            menu.Items.Add(Item("Open screenshots folder", null, delegate { OpenFolder(); }));
            menu.Items.Add(new ToolStripSeparator());

            drawItem = Item("Drawing on", "Esc / Ctrl+Alt+D", delegate { ToggleDraw(); });
            toolbarItem = Item("Show toolbar", "Ctrl+Alt+H", delegate { ToggleToolbar(); });
            menu.Items.Add(drawItem);
            menu.Items.Add(toolbarItem);
            menu.Items.Add(Item("Keyboard shortcuts...", null, Later(delegate { ShowHelp(); })));
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(Item("Exit ScreenDraw", null, Later(delegate { Close(); })));

            foreach (ToolStripItem top in menu.Items)
            {
                ToolStripMenuItem mi = top as ToolStripMenuItem;
                if (mi == null || !mi.HasDropDownItems) continue;
                mi.DropDown.Renderer = menu.Renderer;
                mi.DropDown.Font = menu.Font;
                mi.DropDown.ImageScalingSize = menu.ImageScalingSize;
                ToolStripDropDownMenu dm = mi.DropDown as ToolStripDropDownMenu;
                if (dm != null) { dm.ShowImageMargin = true; dm.ShowCheckMargin = false; }
            }
            menu.ShowCheckMargin = false;
            menu.Opening += delegate { RefreshMenu(); };
        }

        void AddToolItem(ToolStripMenuItem parent, Tool t, string text, string key)
        {
            Tool tool = t;
            ToolStripMenuItem it = Item(text, key, delegate { SetTool(tool); });
            parent.DropDownItems.Add(it);
            toolItems[t] = it;
        }

        void RefreshMenu()
        {
            foreach (KeyValuePair<Tool, ToolStripMenuItem> kv in toolItems) kv.Value.Checked = kv.Key == CurrentTool;
            Color cur = CurrentColor;
            for (int i = 0; i < colorItems.Count; i++) colorItems[i].Checked = Palette[i].ToArgb() == cur.ToArgb();
            for (int i = 0; i < sizeItems.Count; i++) sizeItems[i].Checked = i == sizeIndex;
            undoItem.Enabled = undo.Count > 0;
            redoItem.Enabled = redo.Count > 0;
            clearItem.Enabled = shapes.Count > 0;
            drawItem.Checked = drawMode;
            toolbarItem.Checked = toolbar != null && toolbar.Visible;
        }

        public void ShowMenu(Point screenPt)
        {
            if (menu == null) return;
            menu.Show(screenPt);
        }

        public void SetSizeIndex(int idx)
        {
            ChangeSize(idx - sizeIndex);
        }

        static Bitmap Swatch(Color c, int size)
        {
            Bitmap b = new Bitmap(size, size);
            using (Graphics g = Graphics.FromImage(b))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                using (SolidBrush br = new SolidBrush(c)) g.FillEllipse(br, 1, 1, size - 3, size - 3);
                using (Pen p = new Pen(Color.FromArgb(150, 150, 160), 1f)) g.DrawEllipse(p, 1, 1, size - 3, size - 3);
            }
            return b;
        }

        static Bitmap SizeDot(float w, int size)
        {
            Bitmap b = new Bitmap(size, size);
            using (Graphics g = Graphics.FromImage(b))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                float d = Math.Max(2f, Math.Min(size - 2f, w * size / 26f + 2f));
                g.FillEllipse(Brushes.White, (size - d) / 2f, (size - d) / 2f, d, d);
            }
            return b;
        }

        public void ShowHelp()
        {
            string t =
                "WHILE DRAWING\r\n" +
                "  P  Pen          H  Marker        L  Line        A  Arrow\r\n" +
                "  R  Box          E  Circle        T  Text        X  Eraser\r\n" +
                "  1 - 8  Color            + / -  or mouse wheel  Pen size\r\n" +
                "  Shift  straight lines / perfect square & circle\r\n" +
                "  Ctrl+Z  Undo     Ctrl+Y  Redo     Delete  Clear all\r\n" +
                "  Right-click or M  Open this menu\r\n" +
                "  Esc  Drawing off (use your PC normally, drawings stay)\r\n\r\n" +
                "WORK ANYWHERE\r\n" +
                "  Ctrl+Alt+D  Drawing on / off\r\n" +
                "  Ctrl+Alt+S  Screenshot (full screen)\r\n" +
                "  Ctrl+Alt+R  Snip an area\r\n" +
                "  Ctrl+Alt+C  Clear all drawings\r\n" +
                "  Ctrl+Alt+H  Show / hide toolbar\r\n\r\n" +
                "Screenshots are saved in Pictures\\ScreenDraw and copied (paste with Ctrl+V).";
            MessageBox.Show(t, "ScreenDraw - keyboard shortcuts", MessageBoxButtons.OK, MessageBoxIcon.Information);
            if (drawMode) BringToFrontForDrawing();
        }

        public void OpenFolder()
        {
            try
            {
                if (lastSaved != null && File.Exists(lastSaved))
                    Process.Start("explorer.exe", "/select,\"" + lastSaved + "\"");
                else
                {
                    Directory.CreateDirectory(saveDir);
                    Process.Start("explorer.exe", "\"" + saveDir + "\"");
                }
            }
            catch { }
        }

        static Icon MakeIcon()
        {
            using (Bitmap b = new Bitmap(32, 32, PixelFormat.Format32bppArgb))
            {
                using (Graphics g = Graphics.FromImage(b))
                {
                    g.SmoothingMode = SmoothingMode.AntiAlias;
                    using (SolidBrush bg = new SolidBrush(Color.FromArgb(0, 120, 215))) g.FillEllipse(bg, 1, 1, 30, 30);
                    using (Pen p = new Pen(Color.White, 3.2f))
                    {
                        p.StartCap = LineCap.Round; p.EndCap = LineCap.Round;
                        g.DrawBezier(p, 7, 20, 12, 7, 18, 27, 25, 11);
                    }
                    using (SolidBrush dot = new SolidBrush(Color.FromArgb(255, 214, 0))) g.FillEllipse(dot, 22, 7, 6, 6);
                }
                IntPtr h = b.GetHicon();
                Icon tmp = Icon.FromHandle(h);
                Icon ic = (Icon)tmp.Clone();
                tmp.Dispose();
                Native.DestroyIcon(h);
                return ic;
            }
        }
    }

    // ------------------------------------------------------------------ floating toolbar
    public class Toolbar : Form
    {
        public static readonly Color Bg = Color.FromArgb(32, 32, 36);
        public static readonly Color BtnC = Color.FromArgb(52, 52, 58);
        public static readonly Color Hover = Color.FromArgb(74, 74, 82);
        public static readonly Color Accent = Color.FromArgb(0, 120, 215);
        public static readonly Color OnColor = Color.FromArgb(16, 124, 16);

        Overlay ov;
        float s = 1f;
        ToolTip tip = new ToolTip();
        FlowLayoutPanel flow;
        Dictionary<Tool, Button> toolBtns = new Dictionary<Tool, Button>();
        List<Button> colorBtns = new List<Button>();
        Label sizeLbl;
        Button drawBtn;

        int S(float v) { return (int)Math.Round(v * s); }

        public Toolbar(Overlay o)
        {
            ov = o;
            using (Graphics g = Graphics.FromHwnd(IntPtr.Zero)) s = g.DpiX / 96f;
            Text = "ScreenDraw";
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            StartPosition = FormStartPosition.Manual;
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Bg;
            KeyPreview = true;
            Font = new Font("Segoe UI", 12f * s, FontStyle.Regular, GraphicsUnit.Pixel);
            tip.InitialDelay = 300;

            flow = new FlowLayoutPanel();
            flow.FlowDirection = FlowDirection.LeftToRight;
            flow.WrapContents = false;
            flow.AutoSize = true;
            flow.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            flow.Padding = new Padding(S(4));
            flow.Margin = Padding.Empty;
            flow.BackColor = Bg;
            flow.Location = Point.Empty;
            flow.MouseDown += DragStart;
            Controls.Add(flow);

            Label grip = new Label();
            grip.Size = new Size(S(14), S(30));
            grip.Margin = new Padding(S(2));
            grip.Cursor = Cursors.SizeAll;
            grip.MouseDown += DragStart;
            grip.Paint += delegate(object sender, PaintEventArgs e)
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using (SolidBrush b = new SolidBrush(Color.FromArgb(140, 140, 150)))
                    for (int r = 0; r < 3; r++)
                        for (int c = 0; c < 2; c++)
                            e.Graphics.FillEllipse(b, S(3) + c * S(5), S(8) + r * S(5), S(3), S(3));
            };
            tip.SetToolTip(grip, "Drag to move the toolbar");
            flow.Controls.Add(grip);

            Button menuBtn = AddBtn("Menu", "All options  (or right-click while drawing, or press M)", 50, null);
            menuBtn.Click += delegate { ov.ShowMenu(menuBtn.PointToScreen(new Point(0, menuBtn.Height))); };
            menuBtn.BackColor = Color.FromArgb(66, 66, 74);
            AddSep();

            AddTool(Tool.Pen, "Pen", "Pen  (P)", 40);
            AddTool(Tool.Highlighter, "Marker", "Highlighter  (H)", 54);
            AddTool(Tool.Line, "Line", "Straight line  (L)  - hold Shift to snap angles", 40);
            AddTool(Tool.Arrow, "Arrow", "Arrow  (A)  - hold Shift to snap angles", 48);
            AddTool(Tool.Rect, "Box", "Rectangle  (R)  - hold Shift for a square", 38);
            AddTool(Tool.Ellipse, "Circle", "Ellipse  (E)  - hold Shift for a circle", 50);
            AddTool(Tool.Text, "Text", "Text  (T)  - click where you want to type", 40);
            AddTool(Tool.Eraser, "Eraser", "Eraser  (X)  - removes whole strokes", 52);
            AddSep();

            for (int i = 0; i < Overlay.Palette.Length; i++)
            {
                int idx = i;
                Color c = Overlay.Palette[i];
                Button b = new Button();
                b.FlatStyle = FlatStyle.Flat;
                b.BackColor = c;
                b.FlatAppearance.MouseOverBackColor = c;
                b.FlatAppearance.MouseDownBackColor = c;
                b.Size = new Size(S(22), S(22));
                b.Margin = new Padding(S(2), S(6), S(2), S(6));
                b.TabStop = false;
                b.Cursor = Cursors.Hand;
                b.Click += delegate { ov.SetColor(idx); };
                tip.SetToolTip(b, "Color  (" + (i + 1) + ")");
                flow.Controls.Add(b);
                colorBtns.Add(b);
            }
            AddSep();

            AddBtn("-", "Thinner  (-  or mouse wheel)", 26, delegate { ov.ChangeSize(-1); });
            sizeLbl = new Label();
            sizeLbl.ForeColor = Color.White;
            sizeLbl.TextAlign = ContentAlignment.MiddleCenter;
            sizeLbl.Size = new Size(S(38), S(30));
            sizeLbl.Margin = new Padding(S(2));
            tip.SetToolTip(sizeLbl, "Pen size");
            flow.Controls.Add(sizeLbl);
            AddBtn("+", "Thicker  (+  or mouse wheel)", 26, delegate { ov.ChangeSize(1); });
            AddSep();

            AddBtn("Undo", "Undo  (Ctrl+Z)", 46, delegate { ov.Undo(); });
            AddBtn("Redo", "Redo  (Ctrl+Y)", 46, delegate { ov.Redo(); });
            AddBtn("Clear", "Clear all drawings  (Delete / Ctrl+Alt+C)", 46, delegate { ov.ClearAll(); });
            AddSep();

            Button shot = AddBtn("Screenshot", "Save the whole screen with your drawings  (Ctrl+Alt+S)", 82, delegate { ov.Screenshot(false); });
            shot.BackColor = Accent; shot.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 144, 235);
            Button snip = AddBtn("Snip", "Drag to select an area and save it  (Ctrl+Alt+R)", 46, delegate { ov.Screenshot(true); });
            snip.BackColor = Accent; snip.FlatAppearance.MouseOverBackColor = Color.FromArgb(30, 144, 235);
            AddSep();

            drawBtn = AddBtn("Drawing ON", "ON: draw on the screen.  OFF: use your PC normally, drawings stay visible.  (Esc / Ctrl+Alt+D)", 92, delegate { ov.ToggleDraw(); });
            AddBtn("_", "Hide toolbar  (Ctrl+Alt+H, or double-click the tray icon)", 26, delegate { Hide(); });
            Button close = AddBtn("X", "Exit ScreenDraw", 26, delegate { ov.Close(); });
            close.FlatAppearance.MouseOverBackColor = Color.FromArgb(196, 43, 28);

            flow.PerformLayout();
            Rectangle wa = Screen.PrimaryScreen.WorkingArea;
            if (flow.PreferredSize.Width > wa.Width - S(20))
            {
                flow.WrapContents = true;
                flow.MaximumSize = new Size(wa.Width - S(20), 0);
                flow.PerformLayout();
            }
            ClientSize = flow.PreferredSize;
            Location = new Point(wa.Left + (wa.Width - Width) / 2, wa.Top + S(10));
            UpdateState();
        }

        void AddTool(Tool t, string text, string tipText, int w)
        {
            Tool tool = t;
            Button b = AddBtn(text, tipText, w, delegate { ov.SetTool(tool); });
            toolBtns[t] = b;
        }

        Button AddBtn(string text, string tipText, int w, EventHandler click)
        {
            Button b = new Button();
            b.Text = text;
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.FlatAppearance.MouseOverBackColor = Hover;
            b.BackColor = BtnC;
            b.ForeColor = Color.White;
            b.Font = Font;
            b.Size = new Size(S(w), S(30));
            b.Margin = new Padding(S(2));
            b.Padding = Padding.Empty;
            b.TabStop = false;
            b.UseMnemonic = false;
            if (click != null) b.Click += click;
            tip.SetToolTip(b, tipText);
            flow.Controls.Add(b);
            return b;
        }

        void AddSep()
        {
            Panel p = new Panel();
            p.BackColor = Color.FromArgb(70, 70, 78);
            p.Size = new Size(Math.Max(1, S(1)), S(24));
            p.Margin = new Padding(S(5), S(5), S(5), S(5));
            flow.Controls.Add(p);
        }

        void DragStart(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;
            Native.ReleaseCapture();
            Native.SendMessage(Handle, Native.WM_NCLBUTTONDOWN, (IntPtr)Native.HTCAPTION, IntPtr.Zero);
        }

        public void UpdateState()
        {
            foreach (KeyValuePair<Tool, Button> kv in toolBtns)
                kv.Value.BackColor = kv.Key == ov.CurrentTool && ov.DrawMode ? Accent : BtnC;
            Color cur = ov.CurrentColor;
            for (int i = 0; i < colorBtns.Count; i++)
            {
                bool sel = Overlay.Palette[i].ToArgb() == cur.ToArgb();
                colorBtns[i].FlatAppearance.BorderSize = sel ? Math.Max(2, S(3)) : 1;
                colorBtns[i].FlatAppearance.BorderColor = sel ? Color.White : Color.FromArgb(90, 90, 98);
            }
            sizeLbl.Text = ov.PenWidth + "px";
            drawBtn.Text = ov.DrawMode ? "Drawing ON" : "Drawing OFF";
            drawBtn.BackColor = ov.DrawMode ? OnColor : BtnC;
            drawBtn.FlatAppearance.MouseOverBackColor = ov.DrawMode ? Color.FromArgb(30, 150, 30) : Hover;
        }

        public void EnsureOnScreen()
        {
            Rectangle wa = Screen.FromPoint(Location).WorkingArea;
            if (!wa.IntersectsWith(Bounds))
            {
                wa = Screen.PrimaryScreen.WorkingArea;
                Location = new Point(wa.Left + (wa.Width - Width) / 2, wa.Top + S(10));
            }
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            ov.HandleKey(e);
            if (e.Handled) e.SuppressKeyPress = true;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing) { e.Cancel = true; Hide(); return; }
            base.OnFormClosing(e);
        }
    }

    // ------------------------------------------------------------------ dark menu look
    public class DarkColors : ProfessionalColorTable
    {
        static readonly Color Back = Color.FromArgb(40, 40, 46);
        static readonly Color Sel = Color.FromArgb(66, 66, 76);
        static readonly Color Line = Color.FromArgb(72, 72, 80);
        static readonly Color Acc = Color.FromArgb(0, 120, 215);
        public override Color ToolStripDropDownBackground { get { return Back; } }
        public override Color ImageMarginGradientBegin { get { return Back; } }
        public override Color ImageMarginGradientMiddle { get { return Back; } }
        public override Color ImageMarginGradientEnd { get { return Back; } }
        public override Color ImageMarginRevealedGradientBegin { get { return Back; } }
        public override Color ImageMarginRevealedGradientMiddle { get { return Back; } }
        public override Color ImageMarginRevealedGradientEnd { get { return Back; } }
        public override Color MenuBorder { get { return Line; } }
        public override Color MenuItemBorder { get { return Sel; } }
        public override Color MenuItemSelected { get { return Sel; } }
        public override Color MenuItemSelectedGradientBegin { get { return Sel; } }
        public override Color MenuItemSelectedGradientEnd { get { return Sel; } }
        public override Color MenuItemPressedGradientBegin { get { return Sel; } }
        public override Color MenuItemPressedGradientMiddle { get { return Sel; } }
        public override Color MenuItemPressedGradientEnd { get { return Sel; } }
        public override Color SeparatorDark { get { return Line; } }
        public override Color SeparatorLight { get { return Back; } }
        public override Color CheckBackground { get { return Acc; } }
        public override Color CheckSelectedBackground { get { return Acc; } }
        public override Color CheckPressedBackground { get { return Acc; } }
    }

    public class DarkRenderer : ToolStripProfessionalRenderer
    {
        public DarkRenderer() : base(new DarkColors()) { RoundedEdges = false; }

        protected override void OnRenderItemText(ToolStripItemTextRenderEventArgs e)
        {
            e.TextColor = e.Item.Enabled ? Color.White : Color.FromArgb(120, 120, 128);
            base.OnRenderItemText(e);
        }

        protected override void OnRenderImageMargin(ToolStripRenderEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(Color.FromArgb(40, 40, 46))) e.Graphics.FillRectangle(b, e.AffectedBounds);
        }

        protected override void OnRenderArrow(ToolStripArrowRenderEventArgs e)
        {
            e.ArrowColor = Color.White;
            base.OnRenderArrow(e);
        }

        protected override void OnRenderItemCheck(ToolStripItemImageRenderEventArgs e)
        {
            Rectangle r = e.ImageRectangle;
            r.Inflate(2, 2);
            using (SolidBrush b = new SolidBrush(Color.FromArgb(0, 120, 215))) e.Graphics.FillRectangle(b, r);
            if (e.Item.Image != null) return; // colors / sizes: highlight only
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using (Pen p = new Pen(Color.White, Math.Max(2f, r.Width / 9f)))
            {
                p.StartCap = LineCap.Round; p.EndCap = LineCap.Round; p.LineJoin = LineJoin.Round;
                e.Graphics.DrawLines(p, new PointF[] {
                    new PointF(r.Left + r.Width * 0.25f, r.Top + r.Height * 0.52f),
                    new PointF(r.Left + r.Width * 0.43f, r.Top + r.Height * 0.70f),
                    new PointF(r.Left + r.Width * 0.76f, r.Top + r.Height * 0.32f) });
            }
        }
    }

    // ------------------------------------------------------------------ text box for the Text tool
    public class TextInput : Form
    {
        TextBox box;
        public string Value { get { return box.Text; } }

        public TextInput(Font f, Color c)
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            ShowInTaskbar = false;
            TopMost = true;
            AutoScaleMode = AutoScaleMode.None;
            KeyPreview = true;
            int lum = (int)(0.299 * c.R + 0.587 * c.G + 0.114 * c.B);
            box = new TextBox();
            box.BorderStyle = BorderStyle.FixedSingle;
            box.Font = f;
            box.ForeColor = c;
            box.BackColor = lum > 170 ? Color.FromArgb(45, 45, 50) : Color.White;
            Controls.Add(box);
            ClientSize = new Size(Math.Max(320, f.Height * 14), box.PreferredHeight);
            box.Dock = DockStyle.Fill;
            box.KeyDown += delegate(object sender, KeyEventArgs e)
            {
                if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; DialogResult = DialogResult.OK; }
                else if (e.KeyCode == Keys.Escape) { e.SuppressKeyPress = true; DialogResult = DialogResult.Cancel; }
            };
            Deactivate += delegate
            {
                if (Visible && DialogResult == DialogResult.None)
                    DialogResult = box.Text.Length > 0 ? DialogResult.OK : DialogResult.Cancel;
            };
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            Activate();
            box.Focus();
        }
    }

    // ------------------------------------------------------------------ area picker for "Snip"
    public class RegionSelector : Form
    {
        Bitmap img, dim;
        Point start;
        Rectangle sel = Rectangle.Empty;
        bool dragging;
        public Rectangle Selection { get { return sel; } }

        public RegionSelector(Bitmap full, Rectangle vs)
        {
            img = full;
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            AutoScaleMode = AutoScaleMode.None;
            Bounds = vs;
            TopMost = true;
            ShowInTaskbar = false;
            DoubleBuffered = true;
            Cursor = Cursors.Cross;
            KeyPreview = true;
            dim = new Bitmap(full.Width, full.Height, PixelFormat.Format32bppPArgb);
            using (Graphics g = Graphics.FromImage(dim))
            {
                g.DrawImageUnscaled(full, 0, 0);
                using (SolidBrush b = new SolidBrush(Color.FromArgb(120, 0, 0, 0))) g.FillRectangle(b, 0, 0, full.Width, full.Height);
            }
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            Bounds = SystemInformation.VirtualScreen;
            Activate();
        }

        protected override void OnPaintBackground(PaintEventArgs e) { }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.DrawImage(dim, e.ClipRectangle, e.ClipRectangle, GraphicsUnit.Pixel);
            if (sel.Width > 0 && sel.Height > 0)
            {
                g.DrawImage(img, sel, sel, GraphicsUnit.Pixel);
                using (Pen p = new Pen(Color.FromArgb(0, 150, 255), 2f))
                    g.DrawRectangle(p, sel.X, sel.Y, sel.Width - 1, sel.Height - 1);
                string label = sel.Width + " x " + sel.Height;
                using (Font f = new Font("Segoe UI", 13f, FontStyle.Bold, GraphicsUnit.Pixel))
                {
                    SizeF sz = g.MeasureString(label, f);
                    float ly = sel.Y - sz.Height - 6;
                    if (ly < 0) ly = sel.Y + 6;
                    RectangleF lr = new RectangleF(sel.X, ly, sz.Width + 8, sz.Height + 2);
                    using (SolidBrush bb = new SolidBrush(Color.FromArgb(200, 0, 0, 0))) g.FillRectangle(bb, lr);
                    g.DrawString(label, f, Brushes.White, lr.X + 4, lr.Y + 1);
                }
            }
            else if (!dragging)
            {
                Rectangle pa = Screen.PrimaryScreen.Bounds;
                Rectangle vs = SystemInformation.VirtualScreen;
                string hint = "Drag to select the area to save      (Esc or right-click to cancel)";
                using (Font f = new Font("Segoe UI", 20f, FontStyle.Bold, GraphicsUnit.Pixel))
                {
                    SizeF sz = g.MeasureString(hint, f);
                    float x = pa.X - vs.X + (pa.Width - sz.Width) / 2f;
                    float y = pa.Y - vs.Y + pa.Height * 0.12f;
                    using (SolidBrush bb = new SolidBrush(Color.FromArgb(210, 20, 20, 24)))
                        g.FillRectangle(bb, x - 16, y - 10, sz.Width + 32, sz.Height + 20);
                    g.DrawString(hint, f, Brushes.White, x, y);
                }
            }
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Button == MouseButtons.Right) { DialogResult = DialogResult.Cancel; return; }
            if (e.Button != MouseButtons.Left) return;
            start = e.Location;
            dragging = true;
            sel = Rectangle.Empty;
            Invalidate();
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            if (!dragging) return;
            Rectangle old = sel;
            sel = Shape.Norm(start, e.Location);
            Rectangle inv = old.IsEmpty ? sel : Rectangle.Union(old, sel);
            inv.Inflate(12, 44);
            Invalidate(inv);
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            if (!dragging || e.Button != MouseButtons.Left) return;
            dragging = false;
            if (sel.Width > 3 && sel.Height > 3) DialogResult = DialogResult.OK;
            else { sel = Rectangle.Empty; Invalidate(); }
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            if (e.KeyCode == Keys.Escape) DialogResult = DialogResult.Cancel;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && dim != null) { dim.Dispose(); dim = null; }
            base.Dispose(disposing);
        }
    }

    // ------------------------------------------------------------------ entry point
    public static class Log
    {
        public static string Path;
        public static void Init()
        {
            try
            {
                string dir = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ScreenDraw");
                Directory.CreateDirectory(dir);
                Path = System.IO.Path.Combine(dir, "ScreenDraw-log.txt");
                File.WriteAllText(Path, "ScreenDraw 1.1 log  " + DateTime.Now + "\r\n");
            }
            catch { Path = null; }
        }
        public static void Write(string line)
        {
            if (Path == null) return;
            try { File.AppendAllText(Path, DateTime.Now.ToString("HH:mm:ss.fff") + "  " + line + "\r\n"); } catch { }
        }
    }

    // small "it's running" banner that disappears by itself
    public class StartupNotice : Form
    {
        System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        string text = "ScreenDraw is running - draw anywhere with the mouse.   Esc = use your PC normally.   Right-click = menu.";

        public StartupNotice(int topY)
        {
            float s;
            using (Graphics g = Graphics.FromHwnd(IntPtr.Zero)) s = g.DpiX / 96f;
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            ShowInTaskbar = false;
            TopMost = true;
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.FromArgb(16, 124, 16);
            ForeColor = Color.White;
            Font = new Font("Segoe UI", 15f * s, FontStyle.Bold, GraphicsUnit.Pixel);
            Size sz = TextRenderer.MeasureText(text, Font);
            ClientSize = new Size(sz.Width + (int)(40 * s), sz.Height + (int)(24 * s));
            Rectangle wa = Screen.PrimaryScreen.WorkingArea;
            int y = Math.Max(wa.Top + (int)(70 * s), topY + (int)(14 * s));
            Location = new Point(wa.Left + (wa.Width - Width) / 2, y);
            timer.Interval = 4500;
            timer.Tick += delegate { timer.Stop(); Close(); };
            Click += delegate { Close(); };
        }

        protected override bool ShowWithoutActivation { get { return true; } }

        protected override void OnShown(EventArgs e) { base.OnShown(e); timer.Start(); }

        protected override void OnPaint(PaintEventArgs e)
        {
            TextRenderer.DrawText(e.Graphics, text, Font, ClientRectangle, ForeColor,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) timer.Dispose();
            base.Dispose(disposing);
        }
    }

    public static class Program
    {
        static Mutex mutex;
        const string MutexName = "ScreenDraw_SingleInstance_7f3a";

        [STAThread]
        public static void Main() { Run(); }

        public static void Fail(string what, Exception ex)
        {
            Log.Write("ERROR: " + what + " " + ex);
            try
            {
                MessageBox.Show(what + "\n\n" + ex.GetType().Name + ": " + ex.Message +
                    "\n\nDetails were saved to:\n" + (Log.Path ?? "(log not available)"),
                    "ScreenDraw - problem", MessageBoxButtons.OK, MessageBoxIcon.Error,
                    MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
            }
            catch { }
        }

        public static void Run()
        {
            Log.Init();
            Log.Write("Windows " + Environment.OSVersion.Version + (Environment.Is64BitProcess ? " 64-bit" : " 32-bit") +
                      ", .NET " + Environment.Version + ", exe: " + Application.ExecutablePath);
            try { Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException); } catch { }
            Application.ThreadException += delegate(object sender, ThreadExceptionEventArgs e) { Fail("Something went wrong.", e.Exception); };
            AppDomain.CurrentDomain.UnhandledException += delegate(object sender, UnhandledExceptionEventArgs e)
            {
                Exception ex = e.ExceptionObject as Exception;
                Fail("ScreenDraw crashed.", ex ?? new Exception(Convert.ToString(e.ExceptionObject)));
            };

            bool dpiOk = false;
            try { dpiOk = Native.SetProcessDpiAwarenessContext(new IntPtr(-4)); } catch { }
            if (!dpiOk) { try { dpiOk = Native.SetProcessDPIAware(); } catch { } }
            Log.Write("DPI aware: " + dpiOk);

            bool created;
            mutex = new Mutex(true, MutexName, out created);
            if (!created)
            {
                Log.Write("Another copy is already running.");
                DialogResult r = MessageBox.Show(
                    "ScreenDraw is already running (look for its icon near the clock).\n\n" +
                    "If you can't see it, click Yes to close the old copy and start again.",
                    "ScreenDraw", MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                    MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                if (r != DialogResult.Yes) return;
                try
                {
                    Process me = Process.GetCurrentProcess();
                    foreach (Process p in Process.GetProcessesByName(me.ProcessName))
                        if (p.Id != me.Id) { try { p.Kill(); p.WaitForExit(3000); } catch { } }
                }
                catch { }
                try { created = mutex.WaitOne(4000); }
                catch (AbandonedMutexException) { created = true; }
                if (!created)
                {
                    MessageBox.Show("The old copy could not be closed. Please restart your PC and try again.", "ScreenDraw");
                    return;
                }
                Log.Write("Old copy closed, continuing.");
            }
            try
            {
                Application.EnableVisualStyles();
                try { Application.SetCompatibleTextRenderingDefault(false); } catch { }
                Overlay ov = new Overlay();
                Log.Write("Overlay created, starting.");
                Application.Run(ov);
                Log.Write("Exited normally.");
            }
            catch (Exception ex)
            {
                Fail("ScreenDraw could not start.", ex);
            }
            finally
            {
                try { mutex.ReleaseMutex(); } catch { }
            }
        }
    }
}

'@

try {
    Add-Type -TypeDefinition $code -ReferencedAssemblies System.Windows.Forms, System.Drawing -IgnoreWarnings
    [ScreenDraw.Program]::Run()
}
catch {
    [System.Windows.Forms.MessageBox]::Show("ScreenDraw could not start:`n`n" + $_.Exception.Message, "ScreenDraw") | Out-Null
}

ScreenDraw - draw anywhere on your screen and take screenshots
=============================================================

START
  Double-click ScreenDraw.exe. Nothing to install (Windows 10 / 11).
  If Windows shows "Windows protected your PC", click "More info" -> "Run anyway"
  (this appears because the app is new and not digitally signed).

  Backup option: open the "script-version" folder and double-click
  "Start ScreenDraw.bat". It does exactly the same thing without an .exe.

THE MENU
  Click "Menu" on the toolbar, right-click anywhere while drawing, press M,
  or right-click the tray icon. It has everything in one place:
  tools, colors, pen size, undo/redo/clear, screenshot, snip, "Save screenshot as..."
  (choose folder and PNG/JPG/BMP), open screenshots folder, drawing on/off,
  show toolbar, keyboard shortcuts, and exit.

HOW IT WORKS
  * When it starts, Drawing is ON: draw anywhere on any screen.
  * Press Esc (or the green "Drawing ON" button) to switch drawing OFF.
    Your drawings stay on screen, but you can click and type in your apps normally.
  * Pick any tool or color, or press Ctrl+Alt+D, to start drawing again.
  * Screenshot = saves the whole screen WITH your drawings.
  * Snip      = drag a box to save just that area.
  * Every screenshot is saved to:  Pictures\ScreenDraw\
    and is also copied, so you can paste it straight into WhatsApp, Word, Paint, email (Ctrl+V).
  * The toolbar can be dragged by its dotted handle on the left.
  * ScreenDraw also has an icon in the system tray (near the clock): right-click it for the menu.

TOOLS (keyboard keys work while drawing is ON)
  P  Pen              H  Marker (highlighter)
  L  Line             A  Arrow          (hold Shift = snap to straight / 45 degrees)
  R  Box              E  Circle         (hold Shift = perfect square / circle)
  T  Text (click where you want to type, press Enter to place it)
  X  Eraser (removes whole strokes)
  1-8          choose color
  + / -  or mouse wheel   pen size
  Ctrl+Z / Ctrl+Y         undo / redo
  Delete                  clear all drawings
  Esc                     drawing on/off
  M  or right-click       open the menu

SHORTCUTS THAT WORK ANYWHERE
  Ctrl+Alt+D   drawing on / off
  Ctrl+Alt+S   screenshot (full screen)
  Ctrl+Alt+R   snip an area
  Ctrl+Alt+C   clear all drawings
  Ctrl+Alt+H   show / hide the toolbar

IF NOTHING HAPPENS
  When ScreenDraw starts you should see the toolbar at the top of the screen and a green
  "ScreenDraw is running" banner. If you don't, look for an error message, and send the log file:
    %LOCALAPPDATA%\ScreenDraw\ScreenDraw-log.txt
  (paste that path into the File Explorer address bar and press Enter).

EXIT
  Click X on the toolbar, or right-click the tray icon -> Exit.
